<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="coin_tiles" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../../Graphics/Coins/coin_tiles.png" width="128" height="64"/>
</tileset>
